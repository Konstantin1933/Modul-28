import pytest


@pytest.mark.usefixtures('setup')
class TestHomepage:

    def test_homepage(self):
        pass



